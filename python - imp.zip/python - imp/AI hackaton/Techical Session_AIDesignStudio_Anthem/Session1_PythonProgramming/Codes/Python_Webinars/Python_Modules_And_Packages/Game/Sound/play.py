def music():
    print("This is play module")