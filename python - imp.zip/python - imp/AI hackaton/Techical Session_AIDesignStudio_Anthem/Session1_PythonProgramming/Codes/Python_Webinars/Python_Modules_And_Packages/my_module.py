# This module shows the effect of
#  multiple imports and reload

print("This code got executed")