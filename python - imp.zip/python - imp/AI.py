who is intel team
diff between intel and iis team
tracked and untracked files in git

192.168.99.1

192.168.99.100


1) Big data
Data science is a scientific approach which applies mathematical and statistical ideas and computer tools for processing big data.
Data science is a specialized field that combines multiple areas such as statistics, mathematics, intelligent data capture techniques, data cleansing, mining and programming to prepare and align big data for intelligent analysis to extract insights and information. Though this it may sound simple, data science is quite a challenging area due to the complexities involved in combining and applying different methods, algorithms, and complex programming techniques to perform intelligent analysis in large volumes of data. Hence, the field of data science has evolved from big data, or big data and data science are inseparable
What do Big Data Professionals do?
The responsibilities of big data professional lies around dealing with huge amount of heterogeneous data, which is gathered from various sources coming in at a high velocity.

2) Data science
What does a Data Scientist do?
Data Scientists perform an exploratory analysis to discover insights from the data. They also use various advanced machine learning algorithms to identify the occurrence of a particular event in the future. This involves identifying hidden patterns, unknown correlations, market trends and other useful business information.

3) Data Analytics
What does a Data Analyst do?
Data analysts translate numbers into plain English. Every business collects data, like sales figures, market research, logistics, or transportation costs. A data analyst’s job is to take that data and use it to help companies to make better business decisions.

Data Scientists look at huge volumes of raw data, determine trends, extract insights, use these to create predictive models, and convey their insights to business leadership. Data Analysis, on the other hand, is a more narrow field. Data Analysts typically search for trends within a data set provided by a business team, while Data Scientists are responsible for determining what data sets to look at in the first place, what patterns to seek out and how to apply those insights.

4) AI
Now if we talk about AI, it is completely a different thing from Machine learning and deep learning, actually deep learning and machine learning both are the subsets of AI. There is no fixed definition for AI, you will find a different definition everywhere, but here is a definition that will give you idea of what exactly AI is.
“AI is a ability of computer program to function like a human brain ”

5) ML
Machine learning can be defined as the practice of using algorithms to use data, learn from it and then forecast future trends for that topic

“the study, design and development of the algorithms that give computers the capability to learn without being explicitly programmed.” Machine learning describes the methods used to build AI. Specifically, that means using synthetic neural nets to recognize patterns. If talk of AI sounds futuristic, think again. For anyone ever stunned by Facebook’s uncanny ability to pick out and tag people, Gmail’s ability to filter out spam, or Siri’s voice-recognition talents, machine learning can take the credit.

6) DL
Machine learning uses algorithms to parse data, learn from that data, and make informed decisions based on what it has learned
Deep learning structures algorithms in layers to create an “artificial neural network” that can learn and make intelligent decisions on its own
Deep learning is a subfield of machine learning. While both fall under the broad category of artificial intelligence, deep learning is what powers the most human-like artificial intelligence

Data Driven Decision (with the expectations of better decision and increase value) is process and involves different stages
1)Capture Data
2)Process & Store Data
3)Analyse and Generate Insights
4)Decision & Actions
Big Data is typically involved in Step 2 and that too in all the scenarios.  Based on volume, variety and velocity, one may require Big data & related technologies.  Big Data & Technology helps in reducing cost in processing volume of data and also making it feasible to do a few typically analyses. Data Science is involved in Step 3.  It involves in using Statistical, Mathematical and Machine Learning algorithms to use data and generate insights.

7) Neural network

