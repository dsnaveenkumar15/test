# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 08:42:59 2019

@author: Naven
"""
print('\n')
path = 'C:\\Users\\Pravin\\Desktop\\naveen\\DevOps\\Inter\\Python\\Files\\pega.xlsx'
path1 = 'C:\\Users\\Pravin\\Desktop\\naveen\\DevOps\\Inter\\Python\\Files\\pega1.csv'

import openpyxl 
import pandas as pd
import matplotlib.pyplot as plt

wb = openpyxl.load_workbook(path) 
#sheet = wb.active
sheet = wb['solution']
mx_row = sheet.max_row
mx_col = sheet.max_column
print("Total no. of rows in the sheet =", mx_row)
print("Total no. og columns in the sheet =", mx_col) 
print('\n')

house_df = pd.read_excel(path, sheetname='solution')
print("count =", house_df.shape)
print('\n')
print(house_df)
print('\n')

cols = [1, 2]
rows = [1]
name='solution'
house_df_col = pd.read_excel(path, sheetname=name, usecols=cols, skiprows=rows)
print(house_df_col)
print('\n')



print("Guardrail:")
print("mean","%.2f" % house_df.loc[:,"guardrail"].mean())
print("min","%.2f" % house_df.loc[:,"guardrail"].min())
print ("Max","%.2f" % house_df ["guardrail"].max())
print('\n')


sorted_by_guard = house_df.sort_values(['guardrail'], ascending=False)
sorted_by_guard['guardrail'].head(3)
sorted_by_guard['guardrail'].head(5).plot(kind="barh")
plt.show()
#sorted_by_guard['guardrail'].head(5).plot(kind="hist")
#plt.show()
#sorted_by_gross = movies.sort_values(['Gross Earnings'], ascending=False)
