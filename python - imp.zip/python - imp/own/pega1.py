# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 10:54:10 2019

@author: Pravin
"""

import pandas as pd

path = 'C:\\Users\\Pravin\\Desktop\\naveen\\DevOps\\Inter\\Python\\Files\\pega.xlsx'
df = pd.read_excel(path, sheetname='compass')
print(df)

print("Column headings:")
print(df.columns)

#Using the data frame, we can get all the rows below an entire column as a list.simply use the column header
print(df['guardrail'])
