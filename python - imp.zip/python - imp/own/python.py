laptop: C:\\Users\\Pravin\\Desktop\\naveen\\DevOps\\Inter\\Python\\Files

***********************************************************************************
creating the empty excel
***********************************************************************************

import openpyxl

wb=Workbook()
path='C:\\Users\\n.dhamodharan\\Desktop\\AI\\train_5.xlsx'
wb.save(path)
***********************************************************************************
append the excel
***********************************************************************************
import openpyxl

path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train_4.xlsx'
wb = load_workbook(path)
ws = wb['sheet_1']
data=[('Id','Name','Marks'),
      (1,'ABC',50),
      (2,'CDE',100)]
# append all rows
for row in data:
    ws.append(row)
wb.save(path)
***********************************************************************************
creating the excel with data
***********************************************************************************
import pandas as pd 
  
list1 = ['Assam', 'India', 
         'Lahore', 'Pakistan',  
         'New York', 'USA', 
         'Bejing', 'China'] 

df = pd.DataFrame() 
  
# Creating two columns 
df['State'] = list1[0::2] 
df['Country'] = list1[1::2] 
  
# Converting to excel 
df.to_excel('C:\\Users\\n.dhamodharan\\Desktop\\AI\\train_2.xlsx', index = False) 

***********************************************************************************
writing the excel
***********************************************************************************
import openpyxl

path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
wb = load_workbook(path)
ws = wb['sheet1']
ws['B2'] = 7
ws['i3'] = 8
ws['h10'] = 10
ws.cell(row=8, column=9).value = 3
wb.save(path)
***********************************************************************************
read the excel cell
***********************************************************************************
import xlrd
path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
workbook = xlrd.open_workbook(path)
worksheet = workbook.sheet_by_index(0) #will open first sheet of the file or worksheet = workbook.sheet_by_name('Sheet_Name')
worksheet.cell(4,4).value #(4,4) is the location the cell from which we need to fetch the value
***********************************************************************************
To print the sheet
***********************************************************************************
import pandas as pd
path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
df = pd.read_excel(path)
df.head()
***********************************************************************************
To print the sheet name and create new sheet in the excel file
***********************************************************************************
import openpyxl 
  
path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
wb = openpyxl.load_workbook(path) 
sheet = wb.active 
sheet_title = sheet.title 

print("active sheet title: " + sheet_title) 

# Sheets can be added to workbook with the workbook object's create_sheet() method.  
wb.create_sheet(index = 1 , title = "demo sheet3") 
wb.save(path)
***********************************************************************************
To find the total no. of rowsa nd colunms in the sheet and print the particular rows and columns
***********************************************************************************
import openpyxl 

path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
wb = openpyxl.load_workbook(path) 
sheet = wb.active
mx_row = sheet.max_row
mx_col = sheet.max_column
print("Total no. of rows in the sheet =", mx_row)
print("Total no. og columns in the sheet =", mx_col) 
  
# Loop will print all columns name 
for i in range(1, mx_col + 1): 
    cell_obj = sheet.cell(row = 1, column = i) 
    print(cell_obj.value) 
    
# Loop will print all values of first column  
for i in range(1, mx_row + 1): 
    cell_obj = sheet.cell(row = i, column = 1) 
    print(cell_obj.value)
***********************************************************************************
Print the excel
***********************************************************************************
from openpyxl import load_workbook
filepath='C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
wb=load_workbook(filepath)
sheet=wb.active
max_row=sheet.max_row
max_column=sheet.max_column
for i in range(1,max_row+1):
    for j in range(1,max_column+1):
            cell_obj=sheet.cell(row=i,column=j)
            print(cell_obj.value,end=' | ')
    print('\n')
***********************************************************************************
