import openpyxl

  
path = 'C:\\Users\\n.dhamodharan\\Desktop\\AI\\train.xlsx'
wb = openpyxl.load_workbook(path) 
sheet = wb.active 
sheet_title = sheet.title
mx_row = sheet.max_row
mx_col = sheet.max_column

print("Active sheet title: " + sheet_title) 
print("Total no. of rows in the sheet =", mx_row)
print("Total no. og columns in the sheet =", mx_col)

# Loop will print all columns name (1st row)
for i in range(1, mx_col + 1): 
    cell_obj_head = sheet.cell(row = 1, column = i) 
    print(cell_obj_head.value, end="  ")
    
print('\n') 

# Loop will print the last row
for i in range(1, mx_col + 1): 
    cell_obj_last = sheet.cell(row = mx_row, column = i)
    print(cell_obj_last.value, end="  ") 


#Create new excel sheet
new_file_path='C:\\Users\\n.dhamodharan\\Desktop\\AI\\train_25.xlsx'
wb=openpyxl.Workbook(new_file_path)
wb.save(new_file_path)
