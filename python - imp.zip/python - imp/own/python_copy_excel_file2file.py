import openpyxl

path='C:\\Users\\af30592\\Documents\\Python\\Files\\train.xlsx'


#File to be copied
wb = openpyxl.load_workbook(path) 
Sheet = wb['Sheet'] #sheet_ref = wb.active 
Sheet_title = Sheet.title
mx_row = Sheet.max_row
mx_col = Sheet.max_column

print("Active sheet title: " + Sheet_title) 
print("Total no. of rows in the sheet =", mx_row)
print("Total no. of columns in the sheet =", mx_col)

#Create target excel sheet
new_path='C:\\Users\\af30592\\Documents\\Python\\Files\\train_31.xlsx'
wb=openpyxl.Workbook(new_path)
wb.save(new_path)

#File to be pasted into
target_file = openpyxl.load_workbook(new_path)
target_sheet = target_file['Sheet'] 

def copyRange(startCol, startRow, endCol, endRow, sheet):
    rangeSelected = []
    for i in range(startRow,endRow + 1,1):
        rowSelected = []
        for j in range(startCol,endCol+1,1):
            rowSelected.append(sheet.cell(row = i, column = j).value)
        rangeSelected.append(rowSelected)
    return rangeSelected

def pasteRange(startCol, startRow, endCol, endRow, sheetReceiving,copiedData):
    countRow = 0
    for i in range(startRow,endRow+1,1):
        countCol = 0
        for j in range(startCol,endCol+1,1):
            sheetReceiving.cell(row = i, column = j).value = copiedData[countRow][countCol]
            countCol += 1
        countRow += 1

print("Processing...")
selectedRange = copyRange(1,1,mx_col,mx_row,Sheet)
pastingRange = pasteRange(1,1,mx_col,mx_row,target_sheet,selectedRange)
target_file.save(new_path)
print("Range copied and pasted!")